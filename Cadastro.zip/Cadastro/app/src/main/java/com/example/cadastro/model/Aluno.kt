package com.example.cadastro.model

data class Aluno(val nome: String,
                 val matricula: String = "")
