package com.example.appduastelas.model

data class Produto(val Produto:String,
                   val Preco:Double)

